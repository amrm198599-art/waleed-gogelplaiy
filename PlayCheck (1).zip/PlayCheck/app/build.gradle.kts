import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ks = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.waleedmmh.playcheck"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.waleedmmh.playcheck"
        minSdk = 30
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        if (ks.containsKey("storeFile")) create("release") {
            storeFile = file(ks.getProperty("storeFile"))
            storePassword = ks.getProperty("storePassword")
            keyAlias = ks.getProperty("keyAlias")
            keyPassword = ks.getProperty("keyPassword")
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            signingConfig = signingConfigs.findByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // Android Lint: يعمل مع lintDebug / lintRelease (وفي GitHub Actions) والتقرير في app/build/reports
    lint {
        abortOnError = false
        checkReleaseBuilds = true
        htmlReport = true
        xmlReport = true
        enable += setOf(
            "OldTargetApi", "ExpiredTargetSdkVersion", "MinSdkTooLow", "QueryAllPackagesPermission", "ScopedStorage",
            "RtlEnabled", "RtlHardcoded", "ContentDescription", "AllowBackup", "ObsoleteSdkInt", "UnusedResources",
        )
    }
}

// يفحص سلامة الـ keystore قبل بناء release: فتحه، الـ alias، كلمة مرور المفتاح، والصلاحية بعد 22 أكتوبر 2033
val verifyKeystore by tasks.registering {
    group = "verification"
    description = "Checks keystore.properties points to a readable keystore with a valid long-lived key"
    doLast {
        if (!ks.containsKey("storeFile")) {
            println("verifyKeystore: keystore.properties not found - skipped (release will be unsigned)")
            return@doLast
        }
        val f = file(ks.getProperty("storeFile"))
        if (!f.exists()) throw GradleException("verifyKeystore: keystore file not found: $f")
        val alias = ks.getProperty("keyAlias")
        val store = try {
            java.security.KeyStore.getInstance(f, ks.getProperty("storePassword").toCharArray())
        } catch (e: Exception) {
            throw GradleException("verifyKeystore: cannot open keystore (wrong password or corrupted): ${e.message}")
        }
        val cert = store.getCertificate(alias) as? java.security.cert.X509Certificate
            ?: throw GradleException("verifyKeystore: alias '$alias' not found in keystore")
        try {
            store.getKey(alias, ks.getProperty("keyPassword").toCharArray())
                ?: throw GradleException("verifyKeystore: no private key for alias '$alias'")
        } catch (e: GradleException) {
            throw e
        } catch (e: Exception) {
            throw GradleException("verifyKeystore: wrong key password for alias '$alias': ${e.message}")
        }
        if (cert.notAfter.before(java.util.GregorianCalendar(2033, 9, 22).time))
            throw GradleException("verifyKeystore: key expires ${cert.notAfter}; Google Play requires validity beyond 22 Oct 2033")
        println("verifyKeystore OK: alias=$alias, valid until ${cert.notAfter}")
    }
}
tasks.configureEach {
    if (name == "assembleRelease" || name == "bundleRelease") dependsOn(verifyKeystore)
}
