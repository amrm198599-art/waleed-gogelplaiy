package com.waleedmmh.playcheck

import java.io.ByteArrayInputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.util.GregorianCalendar
import java.util.jar.JarFile
import java.util.zip.ZipFile

/** st: 0 ✅ تمام / OK، 1 ❌ إصلاح / Fix، 2 📝 يدوي / Manual، 3 ⚠️ تنبيه / Warning */
data class Item(val st: Int, val title: String, val body: String, val fix: String? = null, val sum: String = "")

/** كل ما يحتاجه الفحص المسبق من ملف APK أو AAB، بنفس الشكل للنوعين */
class Pkg(
    val isAab: Boolean,
    val fileName: String,
    val fileSize: Long,
    val packageName: String,
    val versionCode: Long,
    val versionName: String,
    val minSdk: Int,
    val targetSdk: Int,
    val permissions: List<String>,
    val labels: Map<String, String>,
    val debuggable: Boolean,
    val cleartext: Boolean,
    val supportsRtl: Boolean,
    val metaData: Map<String, String>,
    val lockedActivities: Int,
    val totalActivities: Int,
    val optOutEdge: Boolean?,
    val certs: List<X509Certificate>,
    val sigSchemes: List<String>,
    val sigError: String?,
    val multipleSigners: Boolean,
    val unsignedEntries: Int,
    val hits: Set<String>,
    val dexScanned: Boolean,
    val abis: Set<String>,
) {
    val label: String get() = labels["default"] ?: ""
}

/** إعدادات الفحص من المستخدم */
class Opts(val production: Boolean, val lastVc: Long?, val sha: String, val title: String) {
    var prev: PrevMeta? = null
}

/** بيانات آخر ملف من النوع الآخر (APK مقابل AAB) للمقارنة */
class PrevMeta(val file: String, val pkg: String, val vc: Long, val vn: String, val label: String, val sha: String)

class Preflight(private val ar: Boolean) {

    private fun t(a: String, e: String) = if (ar) a else e

    private class Lines {
        val rows = ArrayList<Pair<Int, String>>()
        val fix = ArrayList<String>()
        fun add(st: Int, s: String) { rows.add(st to s) }
        fun st(): Int {
            val s = rows.map { it.first }
            return when { 1 in s -> 1; 3 in s -> 3; 2 in s -> 2; else -> 0 }
        }
        fun body() = rows.joinToString("\n") { icon(it.first) + " " + it.second }
        fun fixText(): String? = if (fix.isEmpty()) null else fix.joinToString("\n")
    }

    private fun mk(title: String, l: Lines, forceManual: Boolean = false): Item {
        var st = l.st()
        if (forceManual && st == 0) st = 2
        val row = l.rows.firstOrNull { it.first == st } ?: l.rows.firstOrNull { it.first != 4 } ?: l.rows.firstOrNull()
        val sum = (row?.second ?: "").lineSequence().first().take(90)
        return Item(st, title, l.body(), l.fixText(), sum)
    }

    /** الفحوصات السبعة بالترتيب */
    fun run(p: Pkg, o: Opts): List<Item> = listOf(sdkAds(p), perms(p), uiLint(p), pkgName(p), versions(p, o), signing(p, o), metadata(p, o))

    // ───────────────────────── 1) SDK والإعلانات ─────────────────────────
    private fun sdkAds(p: Pkg): Item {
        val l = Lines()
        val mn = p.minSdk; val tg = p.targetSdk
        var ok = true
        if (mn < 24) { ok = false; l.add(1, t("minSdk = $mn أقل من الحد الأدنى 24.", "minSdk = $mn is below the minimum 24.")); l.fix.add("defaultConfig { minSdk = 24 }") }
        if (mn > 36) { ok = false; l.add(1, t("minSdk = $mn أعلى من 36.", "minSdk = $mn is above 36.")) }
        if (tg < 24 || tg > 36) { ok = false; l.add(1, t("targetSdk = $tg خارج النطاق 24–36.", "targetSdk = $tg is outside 24–36.")); l.fix.add("defaultConfig { targetSdk = 36 }") }
        if (mn > tg) { ok = false; l.add(1, t("minSdk ($mn) أكبر من targetSdk ($tg).", "minSdk ($mn) is greater than targetSdk ($tg).")) }
        if (ok) l.add(0, t("minSdk $mn و targetSdk $tg ضمن النطاق 24–36.", "minSdk $mn and targetSdk $tg are within 24–36."))
        if (ok && tg < 36) l.add(3, t("targetSdk أقل من 36؛ التطبيقات الجديدة والتحديثات تحتاج 36 (راجع بند Target API).", "targetSdk is below 36; new apps and updates need 36 (see the Target API item)."))

        val ads = adLibs.filter { it.first in p.hits }.map { it.second }
        val hasAppId = p.metaData.containsKey("com.google.android.gms.ads.APPLICATION_ID")
        val adId = "AD_ID" in p.permissions
        val adIdFix = "<uses-permission android:name=\"com.google.android.gms.permission.AD_ID\"/>"
        if (ads.isEmpty() && !hasAppId) {
            l.add(0, t("لا توجد مكتبات إعلانية.", "No ad libraries found."))
            if (adId) {
                l.add(3, t("صلاحية AD_ID موجودة بدون مكتبات إعلانية؛ احذفها أو صرّح بها.", "AD_ID permission is present without ad libraries; remove it or declare it."))
                l.fix.add("<uses-permission android:name=\"com.google.android.gms.permission.AD_ID\" tools:node=\"remove\"/>")
            }
        } else {
            val names = ads.ifEmpty { listOf("Google AdMob") }.joinToString(if (ar) "، " else ", ")
            l.add(4, t("مكتبات إعلانية مرصودة: $names", "Ad libraries found: $names"))
            val admob = "com/google/android/gms/ads" in p.hits || hasAppId
            if (admob && !hasAppId) {
                l.add(1, t("AdMob بدون meta-data لمعرّف التطبيق (APPLICATION_ID)؛ التطبيق سينهار عند التشغيل.", "AdMob without the APPLICATION_ID meta-data; the app will crash on launch."))
                l.fix.add("<meta-data android:name=\"com.google.android.gms.ads.APPLICATION_ID\" android:value=\"ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY\"/>")
            }
            val test = "ca-app-pub-3940256099942544" in p.hits || p.metaData.values.any { it.contains("ca-app-pub-3940256099942544") }
            if (test) l.add(1, t("معرّفات اختبار AdMob الرسمية داخل التطبيق؛ استبدلها بمعرّفاتك قبل الرفع.", "Official AdMob test IDs found in the app; replace them with your own IDs before upload."))
            if (tg >= 33 && !adId) { l.add(1, t("إعلانات وtargetSdk ≥ 33 بدون صلاحية AD_ID؛ Play Console سيعترض ومعرّف الإعلانات سيرجع أصفارًا.", "Ads with targetSdk ≥ 33 but no AD_ID permission; Play Console will object and the ad ID returns zeros.")); l.fix.add(adIdFix) }
            if (p.cleartext) l.add(3, t("HTTP غير المشفر مفعّل مع الإعلانات؛ شبكات الإعلانات تتطلب HTTPS.", "Cleartext HTTP is enabled with ads; ad networks require HTTPS."))
            if (admob && "com/google/android/ump" !in p.hits) l.add(3, t("لم يُرصد Consent SDK (UMP)؛ مطلوب للمستخدمين في الاتحاد الأوروبي والمملكة المتحدة.", "No Consent SDK (UMP) detected; required for users in the EEA and UK."))
            if (ads.size > 1) l.add(4, t("أكثر من شبكة إعلانية: تأكد من تحديث كل الـ adapters لنفس جيل الـ SDK.", "More than one ad network: keep all adapters on the same SDK generation."))
            l.add(4, t("حدّث مكتبات الإعلانات لآخر إصدار يدعم minSdk $mn وtargetSdk $tg، واختر نعم في Ads Declaration.", "Update ad libraries to the latest version that supports minSdk $mn and targetSdk $tg, and choose Yes in Ads Declaration."))
        }
        return mk(t("١) توافق SDK والإعلانات", "1) SDK compatibility and ads"), l)
    }

    // ───────────────────────── 2) الأذونات الحساسة ─────────────────────────
    private fun perms(p: Pkg): Item {
        val l = Lines()
        val ps = p.permissions.distinct()
        val rm = ArrayList<String>()
        var highSeen = false; var midSeen = false
        for (s in ps) {
            val tier = when { s in high -> 2; s in mid -> 1; else -> 0 }
            if (tier == 0) continue
            if (tier == 2) highSeen = true else midSeen = true
            val ev = evidence[s]
            val used = ev?.any { it in p.hits }
            val unj = p.dexScanned && ev != null && used == false
            val use = when {
                !p.dexScanned || ev == null -> t("لا يمكن التأكد من استخدامها آليًا", "usage can't be verified automatically")
                unj -> t("لا استخدام لها في الكود (غير مبررة على الأرجح)", "no usage in code (likely unjustified)")
                else -> t("مستخدمة في الكود", "used in code")
            }
            val st = when { tier == 2 && unj -> 1; tier == 2 -> 3; unj -> 3; else -> 4 }
            l.add(st, "$s [" + (if (tier == 2) t("عالية", "high") else t("متوسطة", "medium")) + "] — $use")
            if (unj) rm.add("<uses-permission android:name=\"android.permission.$s\" tools:node=\"remove\"/>")
        }
        val fgs = ps.filter { it.startsWith("FOREGROUND_SERVICE_") }
        if (fgs.isNotEmpty()) l.add(3, t("${fgs.joinToString()} — يلزم تصريح أنواع خدمات المقدمة في Play Console.", "${fgs.joinToString()} — foreground service types must be declared in Play Console."))
        if (highSeen) l.add(4, t("عالية: تتطلب نموذج تصريح في Play Console، وعدم تبريرها قد يؤخر المراجعة أو يرفض التحديث.", "High: needs a declaration form in Play Console; leaving it unjustified can delay review or block the update."))
        if (midSeen) l.add(4, t("متوسطة: تحتاج مبررًا في Data Safety وطلب إذن وقت التشغيل مع شرح للمستخدم.", "Medium: needs a Data Safety justification and a runtime request with a user explanation."))
        if (!highSeen && !midSeen && fgs.isEmpty()) l.add(0, t("لا توجد أذونات حساسة.", "No sensitive permissions."))
        if (rm.isNotEmpty()) { l.fix.add("<!-- xmlns:tools=\"http://schemas.android.com/tools\" -->"); l.fix.addAll(rm) }
        if (p.dexScanned) l.add(4, t("فحص الاستخدام تقديري: يقارن الأذونات بواجهات الكود المعروفة.", "Usage matching is an estimate: it compares permissions with known code APIs."))
        return mk(t("٢) الأذونات الحساسة في Manifest", "2) Sensitive permissions in the Manifest"), l)
    }

    // ───────────────────────── 3) Lint وواجهة المستخدم ─────────────────────────
    private fun uiLint(p: Pkg): Item {
        val l = Lines()
        val tg = p.targetSdk
        val inset = insetEvidence.any { it in p.hits }
        val bars = deprecatedBars.filter { it in p.hits }
        if (!p.dexScanned) {
            l.add(2, t("تعذر قراءة الكود، فلا يمكن فحص Edge-to-Edge آليًا.", "Code could not be read, so edge-to-edge cannot be checked automatically."))
        } else if (tg >= 35) {
            if (inset) l.add(0, t("Edge-to-Edge: فيه معالجة للـ Insets في الكود (تقديري). اختبر على Android 15/16.", "Edge-to-edge: window-insets handling found in code (estimate). Test on Android 15/16."))
            else {
                l.add(1, t("Edge-to-Edge: targetSdk $tg يفرض العرض من الحافة للحافة، ولا توجد معالجة للـ Insets؛ المحتوى سيتداخل مع شريطي الحالة والتنقل.", "Edge-to-edge: targetSdk $tg enforces it and no insets handling was found; content will overlap the status and navigation bars."))
                l.fix.add("// androidx.activity 1.8+\nenableEdgeToEdge()\n// أو بدون مكتبات / or without libraries:\nrootView.setOnApplyWindowInsetsListener { v, i ->\n    val b = i.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())\n    v.setPadding(b.left, b.top, b.right, b.bottom); i\n}")
            }
        } else {
            l.add(3, t("targetSdk $tg: Edge-to-Edge غير مفروض الآن، لكنه إجباري عند الرفع لـ 35+ (مطلوب للمتجر). جهّز معالجة الـ Insets.", "targetSdk $tg: edge-to-edge is not enforced yet but is mandatory at 35+ (needed for the store). Prepare insets handling."))
            if (!inset) l.fix.add("enableEdgeToEdge() // androidx.activity 1.8+")
        }
        if (tg >= 35 && bars.isNotEmpty()) l.add(3, t("استدعاءات قديمة بلا تأثير مع Edge-to-Edge: ${bars.joinToString()} (قد تكون من مكتبة).", "Deprecated calls with no effect under edge-to-edge: ${bars.joinToString()} (may come from a library)."))
        val oo = p.optOutEdge
        if (oo == true) {
            if (tg >= 36) { l.add(1, t("windowOptOutEdgeToEdgeEnforcement مفعّل لكنه لا يعمل مع targetSdk 36.", "windowOptOutEdgeToEdgeEnforcement is set but has no effect with targetSdk 36.")); l.fix.add("<!-- احذف العنصر من الثيم / remove it from the theme -->\n<item name=\"android:windowOptOutEdgeToEdgeEnforcement\">true</item>") }
            else l.add(3, t("windowOptOutEdgeToEdgeEnforcement مفعّل: حل مؤقت يختفي مع targetSdk 36.", "windowOptOutEdgeToEdgeEnforcement is set: a temporary workaround that stops working at targetSdk 36."))
        }
        if (tg >= 36 && p.totalActivities > 0 && p.lockedActivities == p.totalActivities)
            l.add(3, t("كل الشاشات مقفولة على اتجاه واحد؛ Android 16 يتجاهل القفل على الشاشات الكبيرة (≥600dp)، تأكد أن الواجهة تتكيف.", "All screens lock orientation; Android 16 ignores it on large screens (≥600dp), so make sure the UI adapts."))
        if (!p.supportsRtl) l.add(3, t("supportsRtl غير مفعّل؛ الواجهات العربية ستظهر معكوسة (Lint: RtlEnabled).", "supportsRtl is off; RTL layouts will not mirror (Lint: RtlEnabled)."))
        else l.add(0, t("دعم RTL مفعّل.", "RTL support is enabled."))
        if (p.isAab) l.add(4, t("في AAB لا تُقرأ ثيمات الموارد، فالفحص يعتمد على الكود والـ Manifest فقط.", "Resource themes are not read in an AAB, so the check relies on code and the Manifest only."))
        l.add(4, t("Android Lint (lintDebug / lintRelease) مفعّل في build.gradle.kts وفي GitHub Actions، والتقرير في app/build/reports.", "Android Lint (lintDebug / lintRelease) is enabled in build.gradle.kts and GitHub Actions; the report is in app/build/reports."))
        return mk(t("٣) Lint وواجهة المستخدم (Edge-to-Edge)", "3) Lint and UI (edge-to-edge)"), l)
    }

    // ───────────────────────── 4) تفرد اسم الحزمة ─────────────────────────
    private fun pkgName(p: Pkg): Item {
        val l = Lines()
        val n = p.packageName
        val low = n.lowercase()
        var bad = false
        if (!Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+").matches(n) || n.length > 150 || n.split('.').any { it in javaKeywords }) {
            bad = true; l.add(1, t("صيغة اسم الحزمة غير صالحة ($n).", "Invalid package name format ($n)."))
        }
        val reserved = reservedPrefixes.firstOrNull { low.startsWith(it) }
        if (reserved != null) { bad = true; l.add(1, t("الاسم يبدأ بـ $reserved وهو محجوز أو تجريبي ولن يُقبل.", "The name starts with $reserved, which is reserved or a sample name and will be rejected.")); l.fix.add("defaultConfig { applicationId = \"com.yourname.appname\" }") }
        val last = low.substringAfterLast('.')
        if (last in sampleNames) l.add(3, t("آخر جزء ($last) اسم تجريبي شائع؛ اختر اسمًا مميزًا.", "The last segment ($last) is a common sample name; choose a distinctive one."))
        if (n != low) l.add(3, t("يحتوي حروفًا كبيرة؛ يُفضّل الحروف الصغيرة فقط.", "Contains uppercase letters; lowercase only is recommended."))
        var near: String? = null
        for (k in knownPackages) {
            val d = lev(low, k.lowercase())
            if (d <= 2) { near = k; break }
        }
        if (near != null) {
            bad = true
            if (near.equals(n, true)) l.add(1, t("الاسم مطابق لتطبيق معروف ($near).", "The name is identical to a well-known app ($near)."))
            else l.add(1, t("الاسم قريب جدًا من تطبيق معروف ($near)، وقد يُرفض بسبب التشابه.", "The name is very close to a well-known app ($near) and may be rejected for similarity."))
        }
        var manual = false
        if (!bad) {
            val code = playLookup(n)
            when (code) {
                404 -> l.add(0, t("الاسم غير مستخدم في المتجر العام.", "The name is not used in the public store."))
                200 -> l.add(3, t("الاسم موجود فعلًا في Google Play. لو ده تطبيقك (تحديث) فتمام، وإلا غيّره وإلا سيُرفض الرفع.", "This name already exists on Google Play. Fine if it is your own app (an update); otherwise change it or the upload will be rejected."))
                else -> { manual = true; l.add(2, t("تعذر الاتصال بالمتجر للتأكد من التفرد. الفحص المحلي سليم؛ Play Console هو الحكم النهائي.", "Could not reach the store to confirm uniqueness. Local checks pass; Play Console is the final judge.")) }
            }
            if (code != null && code != 200 && code != 404) l.add(4, "HTTP $code")
        }
        if (!bad) l.add(0, t("لا تشابه مع أسماء تطبيقات معروفة، والصيغة سليمة.", "No similarity to well-known app names, and the format is valid."))
        l.add(4, t("الفحص يرسل اسم الحزمة فقط إلى صفحة المتجر العامة.", "This check sends only the package name to the public store page."))
        return mk(t("٤) تفرد اسم الحزمة (Package Name)", "4) Package name uniqueness"), l, manual)
    }

    // ───────────────────────── 5) رقم الإصدار ومرحلة النشر ─────────────────────────
    private fun versions(p: Pkg, o: Opts): Item {
        val l = Lines()
        val vc = p.versionCode; val vn = p.versionName.trim()
        val stage = if (o.production) t("إصدار علني (Production)", "Public release (Production)") else t("اختبار (Internal/Closed/Open)", "Testing (Internal/Closed/Open)")
        l.add(4, t("المرحلة المختارة: $stage", "Selected stage: $stage"))
        l.add(4, "versionCode = $vc ، versionName = " + vn.ifEmpty { "-" })
        if (vc < 1 || vc > 2100000000L) { l.add(1, t("versionCode ($vc) خارج المسموح (1 إلى 2,100,000,000).", "versionCode ($vc) is out of range (1 to 2,100,000,000).")); l.fix.add("defaultConfig { versionCode = 2 }") }
        else l.add(0, t("versionCode ضمن المسموح.", "versionCode is within range."))
        val last = o.lastVc
        var manual = false
        if (last != null) {
            if (vc <= last) { l.add(1, t("versionCode ($vc) لازم يكون أكبر من آخر مرفوع ($last).", "versionCode ($vc) must be greater than the last uploaded ($last).")); l.fix.add("defaultConfig { versionCode = ${last + 1} }") }
            else l.add(0, t("versionCode أكبر من آخر مرفوع ($last).", "versionCode is greater than the last uploaded ($last)."))
        } else manual = true
        if (vn.isEmpty()) { l.add(1, t("versionName فاضي.", "versionName is empty.")); l.fix.add("defaultConfig { versionName = \"1.0.0\" }") }
        else {
            if (!Regex("\\d+(\\.\\d+){0,3}([-+.][0-9A-Za-z.]+)?").matches(vn)) l.add(3, t("صيغة versionName غير قياسية ($vn)؛ المفضل 1.2.3.", "Non-standard versionName format ($vn); 1.2.3 is preferred."))
            val pre = Regex("(?i)(^|[^a-z])(alpha|beta|rc|debug|snapshot|test|dev|internal|preview)([^a-z]|$)").containsMatchIn(vn)
            if (o.production) {
                if (pre) { l.add(1, t("versionName ($vn) يوحي بنسخة تجريبية وأنت اخترت إصدارًا علنيًا.", "versionName ($vn) looks like a pre-release but you selected a public release.")); l.fix.add("defaultConfig { versionName = \"1.0.0\" }") }
                else if (Regex("0(\\.\\d+)*").matches(vn.substringBefore('-'))) l.add(3, t("الإصدار 0.x يبدو تجريبيًا للإصدار العلني.", "A 0.x version looks pre-release for a public release."))
                else l.add(0, t("versionName مناسب للإصدار العلني.", "versionName suits a public release."))
            } else {
                if (pre) l.add(0, t("versionName ($vn) مناسب للاختبار.", "versionName ($vn) suits testing."))
                else l.add(4, t("للاختبار يُفضّل لاحقة مثل -beta أو -rc لتمييزه، لكن غير إلزامي.", "For testing a suffix such as -beta or -rc helps tell builds apart, but it is optional."))
            }
            val major = vn.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
            if (major >= 2 && vc == 1L) l.add(3, t("versionName $vn مع versionCode = 1؛ غالبًا لم تُزد الأرقام معًا.", "versionName $vn with versionCode = 1; the numbers were probably not bumped together."))
        }
        if (manual) l.add(4, t("أدخل آخر versionCode مرفوع في الإعدادات أعلاه لتأكيد أن الجديد أكبر.", "Enter the last uploaded versionCode in the settings above to confirm the new one is higher."))
        return mk(t("٥) رقم الإصدار ومرحلة النشر", "5) Version code/name and release stage"), l, manual)
    }

    // ───────────────────────── 6) التوقيع وسلامة Keystore ─────────────────────────
    private fun signing(p: Pkg, o: Opts): Item {
        val l = Lines()
        val fixSign = "keytool -genkeypair -v -keystore upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000\n# keystore.properties\nstoreFile=upload-key.jks\nstorePassword=****\nkeyAlias=upload\nkeyPassword=****"
        if (p.certs.isEmpty()) {
            if (p.sigError != null) l.add(1, t("فشل التحقق من التوقيع: ${p.sigError}", "Signature verification failed: ${p.sigError}"))
            else { l.add(1, t("الملف غير موقّع.", "The file is not signed.")); l.fix.add(fixSign) }
            return mk(t("٦) التوقيع الرقمي وسلامة Keystore", "6) Digital signature and keystore integrity"), l)
        }
        if (p.sigError != null) l.add(1, t("التوقيع لا يطابق محتوى الملف: ${p.sigError}", "The signature does not match the file contents: ${p.sigError}"))
        else l.add(0, t("التوقيع سليم والملف لم يُعدَّل بعد التوقيع.", "The signature is valid and the file was not modified after signing."))
        l.add(4, t("طرق التوقيع: ", "Signing schemes: ") + p.sigSchemes.joinToString(" + ").ifEmpty { "-" })
        if (!p.isAab && p.targetSdk >= 30 && "v2" !in p.sigSchemes && "v3" !in p.sigSchemes) l.add(1, t("targetSdk 30+ يتطلب توقيع v2 أو أحدث.", "targetSdk 30+ requires a v2 or newer signature."))
        if (p.multipleSigners) l.add(1, t("الملف موقّع بأكثر من مفتاح؛ Play يتطلب مفتاحًا واحدًا.", "The file has several signers; Play requires a single key."))
        if (p.unsignedEntries > 0) l.add(3, t("${p.unsignedEntries} ملف داخل الحزمة غير مشمول بالتوقيع.", "${p.unsignedEntries} entries in the bundle are not covered by the signature."))
        val c = p.certs.firstOrNull { it.subjectX500Principal == it.issuerX500Principal } ?: p.certs[0]
        val dn = c.subjectX500Principal.name
        if (dn.contains("Android Debug", true)) { l.add(1, t("موقّع بمفتاح debug وGoogle Play لا يقبله.", "Signed with a debug key, which Google Play does not accept.")); l.fix.add(fixSign) }
        else l.add(0, t("ليس مفتاح debug.", "Not a debug key."))
        val now = java.util.Date()
        val limit = GregorianCalendar(2033, 9, 22).time
        when {
            c.notAfter.before(now) -> l.add(1, t("شهادة التوقيع منتهية (${c.notAfter}).", "The signing certificate has expired (${c.notAfter})."))
            c.notBefore.after(now) -> l.add(1, t("شهادة التوقيع تبدأ في المستقبل (${c.notBefore}).", "The signing certificate starts in the future (${c.notBefore})."))
            c.notAfter.before(limit) -> { l.add(1, t("صلاحية المفتاح تنتهي قبل 22 أكتوبر 2033 (${c.notAfter})، وGoogle Play يتطلب بعدها.", "The key expires before 22 Oct 2033 (${c.notAfter}); Google Play requires it to last beyond that.")); l.fix.add(fixSign) }
            else -> l.add(0, t("صلاحية المفتاح تمتد بعد 2033.", "The key is valid beyond 2033."))
        }
        val key = c.publicKey
        val alg = c.sigAlgName.uppercase()
        when {
            key is RSAPublicKey && key.modulus.bitLength() < 2048 -> l.add(1, t("مفتاح RSA بطول ${key.modulus.bitLength()} بت؛ المطلوب 2048 على الأقل.", "RSA key of ${key.modulus.bitLength()} bits; 2048 or more is required."))
            key is RSAPublicKey -> l.add(0, "RSA ${key.modulus.bitLength()}")
            key is ECPublicKey -> l.add(0, "EC ${key.params.curve.field.fieldSize}")
            else -> l.add(3, t("نوع مفتاح قديم (${key.algorithm}).", "Legacy key type (${key.algorithm})."))
        }
        if (alg.contains("MD5")) l.add(1, t("خوارزمية الشهادة MD5 غير آمنة.", "The certificate uses MD5, which is insecure."))
        else if (alg.contains("SHA1")) l.add(3, t("خوارزمية الشهادة SHA-1 ضعيفة؛ يُفضّل SHA-256.", "The certificate uses SHA-1, which is weak; SHA-256 is preferred."))
        val fpr = fp(c)
        l.add(4, "SHA-256: $fpr")
        val want = o.sha.filter { it.isLetterOrDigit() }.lowercase()
        if (want.isNotEmpty()) {
            if (want == fpr.replace(":", "").lowercase()) l.add(0, t("البصمة تطابق مفتاح الرفع الذي أدخلته.", "The fingerprint matches the upload key you entered."))
            else l.add(1, t("البصمة لا تطابق مفتاح الرفع المتوقع؛ Play سيرفض الملف (موقّع بمفتاح مختلف).", "The fingerprint does not match the expected upload key; Play will reject the file (signed with a different key)."))
        } else l.add(4, t("أدخل بصمة SHA-256 لمفتاح الرفع (من Play Console) في الإعدادات لمقارنتها.", "Enter the upload key SHA-256 (from Play Console) in the settings to compare it."))
        l.add(4, t("فعّل Play App Signing، وفي build.gradle.kts مهمة verifyKeystore تفحص الـ keystore قبل بناء release.", "Enable Play App Signing; the verifyKeystore Gradle task checks the keystore before release builds."))
        return mk(t("٦) التوقيع الرقمي وسلامة Keystore", "6) Digital signature and keystore integrity"), l)
    }

    // ───────────────────────── 7) البيانات الوصفية والانتحال ─────────────────────────
    private fun metadata(p: Pkg, o: Opts): Item {
        val l = Lines()
        val names = LinkedHashSet<String>()
        p.labels.values.filter { it.isNotBlank() }.forEach { names.add(it) }
        if (names.isEmpty()) l.add(2, t("تعذر قراءة اسم التطبيق (مرجع موارد غير محلول).", "Could not read the app name (unresolved resource reference)."))
        else l.add(4, t("اسم التطبيق: ", "App name: ") + names.joinToString(" | "))
        for (n in names) {
            val b = brandsIn(n)
            if (b.isNotEmpty()) l.add(1, t("الاسم \"$n\" يحتوي علامة تجارية (${b.joinToString()})؛ ينتهك سياسة الانتحال/البيانات الوصفية إلا لو كنت مالكها.", "The name \"$n\" contains a brand (${b.joinToString()}); this violates the impersonation/metadata policy unless you own it."))
            val low = n.lowercase()
            if (n.length > 30) l.add(3, t("الاسم \"$n\" أطول من 30 حرفًا (حد عنوان المتجر).", "The name \"$n\" is longer than 30 characters (store title limit)."))
            if (n.any { Character.getType(it) == Character.OTHER_SYMBOL.toInt() || Character.getType(it) == Character.SURROGATE.toInt() }) l.add(3, t("الاسم \"$n\" فيه إيموجي أو رموز؛ ممنوعة في عنوان التطبيق.", "The name \"$n\" has emoji or symbols, which are not allowed in app titles."))
            val letters = n.filter { it.isLetter() }
            if (letters.length >= 4 && letters == letters.uppercase() && letters != letters.lowercase()) l.add(3, t("الاسم \"$n\" كله حروف كبيرة؛ ممنوع.", "The name \"$n\" is all caps, which is not allowed."))
            val promo = promoWords.filter { containsWord(low, it) }
            if (promo.isNotEmpty()) l.add(3, t("الاسم \"$n\" فيه كلمات ترويجية (${promo.joinToString()}) ممنوعة في العنوان.", "The name \"$n\" has promotional words (${promo.joinToString()}) not allowed in titles."))
        }
        val pk = p.packageName.lowercase()
        brandPrefixes.firstOrNull { pk.startsWith(it) }?.let { l.add(1, t("اسم الحزمة يبدأ بنطاق علامة تجارية ($it)؛ يوحي بالانتحال.", "The package name starts with a brand domain ($it); this suggests impersonation.")) }
        val title = o.title
        if (title.isNotEmpty()) {
            if (title.length > 30) l.add(1, t("عنوان المتجر أطول من 30 حرفًا (${title.length}).", "The store title is longer than 30 characters (${title.length})."))
            val bt = brandsIn(title)
            if (bt.isNotEmpty()) l.add(1, t("عنوان المتجر يحتوي علامة تجارية (${bt.joinToString()}).", "The store title contains a brand (${bt.joinToString()})."))
            val a = norm(title)
            val best = names.map { norm(it) }.filter { it.isNotEmpty() }.minOfOrNull { lev(a, it) }
            if (best != null) {
                if (best <= maxOf(2, a.length / 4)) l.add(0, t("عنوان المتجر يتطابق مع اسم التطبيق داخل الملف.", "The store title matches the in-app name."))
                else l.add(3, t("عنوان المتجر لا يشبه اسم التطبيق داخل الملف؛ توحيدهما يقلل شبهة التضليل.", "The store title differs from the in-app name; aligning them reduces misleading-metadata suspicion."))
            }
        } else l.add(4, t("أدخل عنوان المتجر في الإعدادات لمقارنته باسم التطبيق.", "Enter the store title in the settings to compare it with the app name."))
        val prev = o.prev
        if (prev != null) {
            val other = if (p.isAab) "APK" else "AAB"
            if (prev.pkg != p.packageName) l.add(3, t("آخر ملف $other (${prev.file}) له اسم حزمة مختلف (${prev.pkg}) فلا مقارنة.", "The last $other (${prev.file}) has a different package (${prev.pkg}), so no comparison."))
            else {
                var same = true
                if (prev.vc != p.versionCode) { same = false; l.add(1, t("versionCode مختلف عن $other: ${prev.vc} مقابل ${p.versionCode}.", "versionCode differs from the $other: ${prev.vc} vs ${p.versionCode}.")) }
                if (prev.vn != p.versionName) { same = false; l.add(3, t("versionName مختلف عن $other: ${prev.vn} مقابل ${p.versionName}.", "versionName differs from the $other: ${prev.vn} vs ${p.versionName}.")) }
                if (prev.label.isNotEmpty() && p.label.isNotEmpty() && prev.label != p.label) { same = false; l.add(3, t("اسم التطبيق مختلف عن $other: ${prev.label} مقابل ${p.label}.", "App name differs from the $other: ${prev.label} vs ${p.label}.")) }
                val mine = p.certs.firstOrNull()?.let { fp(it) } ?: ""
                if (prev.sha.isNotEmpty() && mine.isNotEmpty() && prev.sha != mine) { same = false; l.add(1, t("التوقيع مختلف عن $other؛ الملفان من مفتاحين مختلفين.", "The signature differs from the $other; the files use different keys.")) }
                if (same) l.add(0, t("البيانات تطابق آخر $other تم فحصه (${prev.file}).", "Data matches the last $other checked (${prev.file})."))
            }
        } else l.add(4, t("افحص ملف ${if (p.isAab) "APK" else "AAB"} لنفس الإصدار لمقارنة بياناتهما تلقائيًا.", "Check the ${if (p.isAab) "APK" else "AAB"} of the same build to compare both automatically."))
        return mk(t("٧) البيانات الوصفية وتجنب الانتحال", "7) Metadata and impersonation"), l)
    }

    private fun brandsIn(text: String): List<String> {
        val low = text.lowercase()
        return brands.filter { containsWord(low, it) }
    }

    companion object {
        fun icon(st: Int) = arrayOf("✅", "❌", "📝", "⚠️", "ℹ️")[st]

        val adLibs = listOf(
            "com/google/android/gms/ads" to "Google AdMob", "com/facebook/ads" to "Meta Audience Network", "com/unity3d/ads" to "Unity Ads",
            "com/applovin" to "AppLovin", "com/ironsource" to "ironSource", "com/chartboost" to "Chartboost", "com/vungle" to "Vungle / Liftoff",
            "com/adcolony" to "AdColony", "com/mbridge" to "Mintegral", "com/bytedance/sdk/openadsdk" to "Pangle", "com/inmobi" to "InMobi",
            "com/startapp" to "StartApp", "com/appodeal" to "Appodeal", "com/yandex/mobile/ads" to "Yandex Ads",
        )

        private val insetEvidence = listOf(
            "setOnApplyWindowInsetsListener", "enableEdgeToEdge", "setDecorFitsSystemWindows", "WindowInsetsCompat", "onApplyWindowInsets",
            "androidx/compose/foundation/layout/WindowInsets", "getInsets",
        )
        private val deprecatedBars = listOf("setStatusBarColor", "setNavigationBarColor", "setNavigationBarDividerColor")

        private val evidence: Map<String, List<String>> = mapOf(
            "CAMERA" to listOf("android/hardware/camera2", "androidx/camera/", "android/hardware/Camera"),
            "RECORD_AUDIO" to listOf("android/media/MediaRecorder", "android/media/AudioRecord", "android/speech/SpeechRecognizer"),
            "ACCESS_FINE_LOCATION" to listOf("android/location/LocationManager", "com/google/android/gms/location/", "android/location/Location"),
            "ACCESS_COARSE_LOCATION" to listOf("android/location/LocationManager", "com/google/android/gms/location/", "android/location/Location"),
            "ACCESS_BACKGROUND_LOCATION" to listOf("android/location/LocationManager", "com/google/android/gms/location/"),
            "READ_CONTACTS" to listOf("android/provider/ContactsContract"), "WRITE_CONTACTS" to listOf("android/provider/ContactsContract"),
            "READ_CALENDAR" to listOf("android/provider/CalendarContract"), "WRITE_CALENDAR" to listOf("android/provider/CalendarContract"),
            "READ_PHONE_STATE" to listOf("android/telephony/TelephonyManager"), "READ_PHONE_NUMBERS" to listOf("android/telephony/TelephonyManager"),
            "READ_SMS" to listOf("android/telephony/SmsManager", "android/provider/Telephony"), "RECEIVE_SMS" to listOf("android/telephony/SmsManager", "android/provider/Telephony"),
            "SEND_SMS" to listOf("android/telephony/SmsManager"),
            "READ_CALL_LOG" to listOf("android/provider/CallLog"), "WRITE_CALL_LOG" to listOf("android/provider/CallLog"),
            "CALL_PHONE" to listOf("android.intent.action.CALL"),
            "BLUETOOTH_SCAN" to listOf("android/bluetooth/"), "BLUETOOTH_CONNECT" to listOf("android/bluetooth/"), "BLUETOOTH_ADVERTISE" to listOf("android/bluetooth/"),
            "QUERY_ALL_PACKAGES" to listOf("getInstalledPackages", "getInstalledApplications"),
            "REQUEST_INSTALL_PACKAGES" to listOf("android/content/pm/PackageInstaller", "application/vnd.android.package-archive"),
            "MANAGE_EXTERNAL_STORAGE" to listOf("isExternalStorageManager"),
            "SCHEDULE_EXACT_ALARM" to listOf("setExact", "setAlarmClock"), "USE_EXACT_ALARM" to listOf("setExact", "setAlarmClock"),
            "USE_FULL_SCREEN_INTENT" to listOf("setFullScreenIntent"),
            "BIND_ACCESSIBILITY_SERVICE" to listOf("android/accessibilityservice/AccessibilityService"),
            "BIND_VPN_SERVICE" to listOf("android/net/VpnService"),
            "READ_MEDIA_IMAGES" to listOf("android/provider/MediaStore"), "READ_MEDIA_VIDEO" to listOf("android/provider/MediaStore"),
        )

        /** كل النصوص التي يبحث عنها الفحص داخل ملفات dex */
        val patterns: List<String> = (adLibs.map { it.first } + evidence.values.flatten() + insetEvidence + deprecatedBars +
            listOf("ca-app-pub-3940256099942544", "com/google/android/ump")).distinct()

        private val high = setOf(
            "READ_SMS", "RECEIVE_SMS", "SEND_SMS", "RECEIVE_MMS", "RECEIVE_WAP_PUSH", "READ_CALL_LOG", "WRITE_CALL_LOG", "PROCESS_OUTGOING_CALLS",
            "MANAGE_EXTERNAL_STORAGE", "QUERY_ALL_PACKAGES", "REQUEST_INSTALL_PACKAGES", "SYSTEM_ALERT_WINDOW", "ACCESS_BACKGROUND_LOCATION",
            "USE_FULL_SCREEN_INTENT", "BIND_ACCESSIBILITY_SERVICE", "BIND_VPN_SERVICE", "BIND_DEVICE_ADMIN", "READ_MEDIA_IMAGES", "READ_MEDIA_VIDEO",
            "USE_EXACT_ALARM", "SCHEDULE_EXACT_ALARM",
        )
        private val mid = setOf(
            "CAMERA", "RECORD_AUDIO", "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "READ_CONTACTS", "WRITE_CONTACTS", "GET_ACCOUNTS",
            "READ_CALENDAR", "WRITE_CALENDAR", "READ_PHONE_STATE", "READ_PHONE_NUMBERS", "CALL_PHONE", "ANSWER_PHONE_CALLS", "BODY_SENSORS",
            "ACTIVITY_RECOGNITION", "BLUETOOTH_SCAN", "BLUETOOTH_CONNECT", "BLUETOOTH_ADVERTISE", "NEARBY_WIFI_DEVICES", "READ_EXTERNAL_STORAGE",
            "WRITE_EXTERNAL_STORAGE", "READ_MEDIA_AUDIO", "READ_MEDIA_VISUAL_USER_SELECTED",
        )

        private val javaKeywords = setOf(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else",
            "enum", "extends", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long",
            "native", "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized",
            "this", "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null",
        )
        private val reservedPrefixes = listOf("com.example", "com.android.", "android.", "com.google.", "com.sample", "com.test.", "com.yourcompany", "com.mycompany", "com.company")
        private val sampleNames = setOf("test", "testapp", "demo", "sample", "myapplication", "myapp", "helloworld", "app", "application", "project")
        private val knownPackages = listOf(
            "com.whatsapp", "com.facebook.katana", "com.facebook.orca", "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
            "org.telegram.messenger", "com.snapchat.android", "com.twitter.android", "com.google.android.youtube", "com.google.android.apps.maps",
            "com.google.android.gm", "com.android.chrome", "com.spotify.music", "com.netflix.mediaclient", "com.amazon.mShop.android.shopping",
            "com.paypal.android.p2pmobile", "com.microsoft.office.word", "com.supercell.clashofclans", "com.king.candycrushsaga", "com.kiloo.subwaysurf",
            "com.mojang.minecraftpe", "com.dts.freefireth", "com.tencent.ig", "com.discord", "com.viber.voip", "com.skype.raider", "com.ubercab",
            "com.binance.dev", "com.openai.chatgpt", "com.google.android.apps.photos", "com.android.vending",
        )
        private val brands = listOf(
            "google", "google play", "whatsapp", "facebook", "instagram", "tiktok", "youtube", "telegram", "snapchat", "twitter", "netflix", "spotify",
            "samsung", "huawei", "microsoft", "amazon", "paypal", "binance", "chatgpt", "openai", "gmail", "apple", "iphone",
            "جوجل", "قوقل", "واتساب", "واتس اب", "فيسبوك", "فيس بوك", "انستجرام", "إنستغرام", "انستغرام", "تيك توك", "يوتيوب", "تليجرام", "تيليجرام",
            "سناب شات", "سامسونج", "نتفلكس", "بايبال", "بينانس", "آبل",
        )
        private val brandPrefixes = listOf(
            "com.facebook.", "com.whatsapp", "com.instagram.", "com.samsung.", "com.microsoft.", "com.amazon.", "com.huawei.", "com.tiktok",
            "com.zhiliaoapp", "org.telegram", "com.snapchat.", "com.twitter.", "com.netflix.", "com.paypal.", "com.spotify.", "com.apple.",
        )
        private val promoWords = listOf("best", "#1", "free", "sale", "official", "original", "الأفضل", "رسمي", "مجاني")

        private fun containsWord(low: String, w: String): Boolean =
            if (w.all { it.code < 128 }) Regex("(^|[^a-z0-9])" + Regex.escape(w) + "([^a-z0-9]|$)").containsMatchIn(low) else low.contains(w)

        private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

        private fun lev(a: String, b: String): Int {
            val d = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                var prev = d[0]; d[0] = i
                for (j in 1..b.length) {
                    val tmp = d[j]
                    d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                    prev = tmp
                }
            }
            return d[b.length]
        }

        fun fp(c: X509Certificate): String =
            MessageDigest.getInstance("SHA-256").digest(c.encoded).joinToString(":") { "%02X".format(it) }

        /** 200 = موجود في المتجر، 404 = غير موجود، null = تعذر الاتصال */
        fun playLookup(pkg: String): Int? = try {
            val c = URL("https://play.google.com/store/apps/details?id=" + URLEncoder.encode(pkg, "UTF-8") + "&hl=en").openConnection() as HttpURLConnection
            c.requestMethod = "GET"; c.connectTimeout = 8000; c.readTimeout = 8000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) PlayCheck")
            val code = c.responseCode
            c.disconnect()
            code
        } catch (_: Exception) { null }

        /** يبحث عن النصوص المطلوبة داخل ملفات dex واحدًا واحدًا (بدون تجميعها كلها في الذاكرة) */
        fun scanDex(z: ZipFile, dexNames: List<String>, patterns: Collection<String>): Set<String> {
            val found = HashSet<String>()
            for (n in dexNames) {
                val e = z.getEntry(n) ?: continue
                val s = String(z.getInputStream(e).use { it.readBytes() }, Charsets.ISO_8859_1)
                for (p in patterns) if (p !in found && s.contains(p)) found.add(p)
                if (found.size == patterns.size) break
            }
            return found
        }

        private fun le32(b: ByteArray, o: Int): Long =
            (b[o].toLong() and 255) or ((b[o + 1].toLong() and 255) shl 8) or ((b[o + 2].toLong() and 255) shl 16) or ((b[o + 3].toLong() and 255) shl 24)

        private fun le64(b: ByteArray, o: Int = 0): Long = le32(b, o) or (le32(b, o + 4) shl 32)

        /** طرق توقيع APK الموجودة في APK Signing Block: v2 / v3 / v3.1 */
        fun apkSchemes(f: File): List<String> {
            val out = LinkedHashSet<String>()
            try {
                val hasV1 = ZipFile(f).use { z ->
                    java.util.Collections.list(z.entries()).any { Regex("META-INF/.+\\.(RSA|DSA|EC)", RegexOption.IGNORE_CASE).matches(it.name) }
                }
                if (hasV1) out.add("v1")
                RandomAccessFile(f, "r").use { r ->
                    val len = r.length()
                    val n = minOf(len, 70000L).toInt()
                    val tail = ByteArray(n); r.seek(len - n); r.readFully(tail)
                    var cd = -1L
                    for (i in n - 22 downTo 0) {
                        if (tail[i] == 0x50.toByte() && tail[i + 1] == 0x4b.toByte() && tail[i + 2] == 5.toByte() && tail[i + 3] == 6.toByte()) { cd = le32(tail, i + 16); break }
                    }
                    if (cd >= 32) {
                        val m = ByteArray(16); r.seek(cd - 16); r.readFully(m)
                        if (String(m, Charsets.ISO_8859_1) == "APK Sig Block 42") {
                            val sz = ByteArray(8); r.seek(cd - 24); r.readFully(sz)
                            val start = cd - le64(sz) - 8
                            var pos = start + 8
                            val endPairs = cd - 24
                            while (start >= 0 && pos + 12 <= endPairs) {
                                val h = ByteArray(12); r.seek(pos); r.readFully(h)
                                val l = le64(h)
                                when (le32(h, 8)) { 0x7109871aL -> out.add("v2"); 0xf05368c0L -> out.add("v3"); 0x1b93ad61L -> out.add("v3.1") }
                                if (l <= 0) break
                                pos += 8 + l
                            }
                        }
                    }
                    Unit
                }
            } catch (_: Exception) {}
            return out.toList()
        }

        // ───────────── قراءة AAB (Manifest بصيغة protobuf من aapt2) ─────────────
        private class F(val no: Int, val wt: Int, val num: Long, val off: Int, val len: Int) {
            fun str(b: ByteArray) = String(b, off, len, Charsets.UTF_8)
        }

        private fun fields(b: ByteArray, from: Int = 0, to: Int = b.size): List<F> {
            val out = ArrayList<F>()
            var p = from
            fun vi(): Long {
                var r = 0L; var s = 0
                while (s <= 63) {
                    if (p >= to) throw IllegalArgumentException("eof")
                    val x = b[p++].toInt() and 0xff
                    r = r or ((x and 0x7f).toLong() shl s)
                    if (x < 0x80) return r
                    s += 7
                }
                throw IllegalArgumentException("bad varint")
            }
            while (p < to) {
                val key = vi(); val no = (key ushr 3).toInt(); val wt = (key and 7).toInt()
                when (wt) {
                    0 -> out.add(F(no, wt, vi(), 0, 0))
                    1 -> { if (p + 8 > to) throw IllegalArgumentException("eof"); out.add(F(no, wt, 0, p, 8)); p += 8 }
                    2 -> { val l = vi().toInt(); if (l < 0 || p + l > to) throw IllegalArgumentException("eof"); out.add(F(no, wt, 0, p, l)); p += l }
                    5 -> { if (p + 4 > to) throw IllegalArgumentException("eof"); out.add(F(no, wt, 0, p, 4)); p += 4 }
                    else -> throw IllegalArgumentException("bad wire type")
                }
            }
            return out
        }

        private class XEl(val name: String, val attrs: Map<String, String>, val kids: List<XEl>) {
            fun all(n: String): List<XEl> = (if (name == n) listOf(this) else emptyList()) + kids.flatMap { it.all(n) }
        }

        private fun xmlNode(b: ByteArray, off: Int, len: Int): XEl? {
            val el = fields(b, off, off + len).firstOrNull { it.no == 1 && it.wt == 2 } ?: return null
            return xmlEl(b, el.off, el.len)
        }

        private fun xmlEl(b: ByteArray, off: Int, len: Int): XEl {
            var name = ""
            val attrs = LinkedHashMap<String, String>()
            val kids = ArrayList<XEl>()
            for (f in fields(b, off, off + len)) {
                if (f.wt != 2) continue
                when (f.no) {
                    3 -> name = f.str(b)
                    4 -> {
                        var an = ""; var av = ""; var prim = ""
                        for (a in fields(b, f.off, f.off + f.len)) {
                            if (a.wt != 2) continue
                            when (a.no) {
                                2 -> an = a.str(b)
                                3 -> av = a.str(b)
                                6 -> for (i in fields(b, a.off, a.off + a.len)) if (i.no == 7 && i.wt == 2) for (pr in fields(b, i.off, i.off + i.len)) when (pr.no) {
                                    6, 7 -> prim = pr.num.toString()
                                    8 -> prim = if (pr.num != 0L) "true" else "false"
                                }
                            }
                        }
                        if (av.isEmpty() && prim.isNotEmpty()) av = prim
                        if (an.isNotEmpty()) attrs[an] = av
                    }
                    5 -> xmlNode(b, f.off, f.len)?.let { kids.add(it) }
                }
            }
            return XEl(name, attrs, kids)
        }

        private fun num(s: String?): Long? = if (s == null) null else if (s.startsWith("0x")) s.substring(2).toLongOrNull(16) else s.toLongOrNull()

        /** يجلب قيمة string/<name> الافتراضية من resources.pb (ResourceTable) */
        private fun aabString(res: ByteArray, name: String): String? {
            try {
                for (pk in fields(res).filter { it.no == 2 && it.wt == 2 }) {
                    for (ty in fields(res, pk.off, pk.off + pk.len).filter { it.no == 3 && it.wt == 2 }) {
                        val tf = fields(res, ty.off, ty.off + ty.len)
                        if (tf.none { it.no == 2 && it.wt == 2 && it.str(res) == "string" }) continue
                        for (en in tf.filter { it.no == 3 && it.wt == 2 }) {
                            val ef = fields(res, en.off, en.off + en.len)
                            if (ef.none { it.no == 2 && it.wt == 2 && it.str(res) == name }) continue
                            var best: String? = null
                            for (cv in ef.filter { it.no == 6 && it.wt == 2 }) {
                                val cf = fields(res, cv.off, cv.off + cv.len)
                                val isDefault = cf.none { it.no == 1 && it.wt == 2 && it.len > 0 }
                                val v = cf.firstOrNull { it.no == 2 && it.wt == 2 } ?: continue
                                val item = fields(res, v.off, v.off + v.len).firstOrNull { it.no == 4 && it.wt == 2 } ?: continue
                                val st = fields(res, item.off, item.off + item.len).firstOrNull { (it.no == 2 || it.no == 3) && it.wt == 2 } ?: continue
                                val s = fields(res, st.off, st.off + st.len).firstOrNull { it.no == 1 && it.wt == 2 }?.str(res) ?: continue
                                if (isDefault) return s
                                if (best == null) best = s
                            }
                            return best
                        }
                    }
                }
            } catch (_: Exception) {}
            return null
        }

        /** يتحقق من توقيع JAR للـ AAB ويقرأ كل الملفات؛ يرجع (رسالة خطأ أو null، عدد الملفات غير الموقعة) */
        private fun jarVerify(f: File): Pair<String?, Int> {
            var err: String? = null
            var unsigned = 0
            try {
                JarFile(f, true).use { jar ->
                    val en = jar.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (e.isDirectory) continue
                        jar.getInputStream(e).use { s -> val buf = ByteArray(65536); while (s.read(buf) >= 0) { } }
                        if (!e.name.startsWith("META-INF/") && e.certificates.isNullOrEmpty()) unsigned++
                    }
                }
            } catch (x: SecurityException) {
                err = x.message ?: "invalid signature"
            } catch (x: Exception) {
                err = x.message ?: x.toString()
            }
            return err to unsigned
        }

        fun readAab(f: File, fileName: String, extra: List<String> = emptyList()): Pkg {
            val sigRe = Regex("META-INF/.+\\.(RSA|DSA|EC)", RegexOption.IGNORE_CASE)
            val dexRe = Regex("[^/]+/dex/classes\\d*\\.dex")
            val libRe = Regex("[^/]+/lib/([^/]+)/.+\\.so")
            var hasSf = false
            val certs = ArrayList<X509Certificate>()
            val dexNames = ArrayList<String>(); val abis = sortedSetOf<String>()
            var root: XEl? = null; var resBytes: ByteArray? = null
            var hits: Set<String> = emptySet()
            ZipFile(f).use { z ->
                val me = z.getEntry("base/manifest/AndroidManifest.xml") ?: throw IllegalStateException("base/manifest/AndroidManifest.xml not found")
                val mb = z.getInputStream(me).use { it.readBytes() }
                root = xmlNode(mb, 0, mb.size)
                z.getEntry("base/resources.pb")?.let { e -> resBytes = z.getInputStream(e).use { it.readBytes() } }
                for (e in z.entries()) {
                    val n = e.name
                    if (dexRe.matches(n)) dexNames.add(n)
                    libRe.matchEntire(n)?.let { abis.add(it.groupValues[1]) }
                    if (n.startsWith("META-INF/") && n.endsWith(".SF", true)) hasSf = true
                    if (sigRe.matches(n)) {
                        try {
                            val cs = CertificateFactory.getInstance("X.509").generateCertificates(ByteArrayInputStream(z.getInputStream(e).use { it.readBytes() }))
                            cs.filterIsInstance<X509Certificate>().forEach { certs.add(it) }
                        } catch (_: Exception) {}
                    }
                }
                hits = scanDex(z, dexNames, (patterns + extra).distinct())
            }
            val r = root ?: throw IllegalStateException("Manifest could not be parsed")
            val sdk = r.all("uses-sdk").firstOrNull()?.attrs ?: emptyMap()
            val mn = num(sdk["minSdkVersion"])?.toInt() ?: 1
            val tg = num(sdk["targetSdkVersion"])?.toInt() ?: mn
            val app = r.all("application").firstOrNull()
            val aa = app?.attrs ?: emptyMap()
            val perms = (r.all("uses-permission") + r.all("uses-permission-sdk-23")).mapNotNull { it.attrs["name"]?.substringAfterLast('.') }
            val meta = LinkedHashMap<String, String>()
            app?.all("meta-data")?.forEach { m -> m.attrs["name"]?.let { meta[it] = m.attrs["value"] ?: m.attrs["resource"] ?: "" } }
            val acts = app?.all("activity") ?: emptyList()
            val lockedVals = setOf("portrait", "landscape", "reverseportrait", "reverselandscape", "sensorportrait", "sensorlandscape", "userportrait", "userlandscape", "locked", "0", "1", "6", "7", "8", "9", "11", "12", "14")
            val locked = acts.count { (it.attrs["screenOrientation"] ?: "").lowercase() in lockedVals }
            var label = aa["label"] ?: ""
            if (label.startsWith("@string/")) label = resBytes?.let { aabString(it, label.removePrefix("@string/")) } ?: ""
            val labels = LinkedHashMap<String, String>(); labels["default"] = label
            val jar = if (hasSf) jarVerify(f) else null to 0
            return Pkg(
                isAab = true, fileName = fileName, fileSize = f.length(),
                packageName = r.attrs["package"] ?: "", versionCode = num(r.attrs["versionCode"]) ?: 0L, versionName = r.attrs["versionName"] ?: "",
                minSdk = mn, targetSdk = tg, permissions = perms, labels = labels,
                debuggable = aa["debuggable"] == "true", cleartext = aa["usesCleartextTraffic"] == "true", supportsRtl = aa["supportsRtl"] == "true",
                metaData = meta, lockedActivities = locked, totalActivities = acts.size, optOutEdge = null,
                certs = if (certs.isEmpty()) emptyList() else listOf(certs.firstOrNull { it.subjectX500Principal == it.issuerX500Principal } ?: certs[0]),
                sigSchemes = if (hasSf) listOf("JAR (v1)") else emptyList(), sigError = jar.first, multipleSigners = false, unsignedEntries = jar.second,
                hits = hits, dexScanned = dexNames.isNotEmpty(), abis = abis,
            )
        }
    }
}
