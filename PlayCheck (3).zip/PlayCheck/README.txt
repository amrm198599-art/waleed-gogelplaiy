1) افتح المجلد PlayCheck في Android Studio (File > Open) وانتظر Gradle Sync.
2) شغّل على موبايل أو محاكي، واختر ملف APK أو AAB.
3) التطبيق يعرض تقرير الفحص المسبق (7 فحوصات): SDK والإعلانات، الأذونات، Lint وEdge-to-Edge،
   اسم الحزمة، رقم الإصدار، التوقيع والـ Keystore، البيانات الوصفية والانتحال. ثم متطلبات Google Play الإضافية.
4) الإعدادات الاختيارية داخل التطبيق: مرحلة النشر (اختبار/علني)، آخر versionCode مرفوع،
   بصمة SHA-256 لمفتاح الرفع، وعنوان المتجر.
5) للتوقيع: انسخ keystore.properties.example باسم keystore.properties واملأه.
   مهمة verifyKeystore تفحص الـ keystore تلقائيًا قبل assembleRelease / bundleRelease.
6) Lint: gradle lintDebug (أو lintRelease) والتقرير في app/build/reports.
