1) افتح المجلد PlayCheck في Android Studio (File > Open) وانتظر Gradle Sync.
2) شغّل على موبايل أو محاكي، واختر ملف APK.
3) للتوقيع: انسخ keystore.properties.example باسم keystore.properties واملأه،
   أو استخدم Build > Generate Signed Bundle / APK.
